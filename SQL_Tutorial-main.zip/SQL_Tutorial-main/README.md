# SQL_Tutorial
SQL Tutorial In Hindi

## Complete SQL Tutorial playlist: https://www.youtube.com/playlist?list=PLdOKnrf8EcP17p05q13WXbHO5Z_JfXNpw
